import { combineReducers } from 'redux';

 import cards from "./cards"
export const reducers = combineReducers({ cards });
